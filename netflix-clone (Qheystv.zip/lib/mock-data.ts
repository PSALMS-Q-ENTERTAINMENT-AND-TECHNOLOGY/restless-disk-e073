export type ContentItem = {
  id: string
  title: string
  description?: string
  coverImage: string
  thumbnailImage?: string
  releaseYear?: number
  duration?: string
  rating?: string
  genre?: string[]
}

export type ContentCategory = {
  id: string
  title: string
  description?: string
  coverImage?: string
  items?: ContentItem[]
}

export const mockContent: ContentCategory[] = [
  {
    id: "featured",
    title: "Stranger Things",
    description:
      "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces and one strange little girl.",
    coverImage: "/placeholder.svg?height=800&width=1600",
  },
  {
    id: "trending",
    title: "Trending Now",
    items: [
      {
        id: "movie1",
        title: "The Crown",
        description:
          "This drama follows the political rivalries and romance of Queen Elizabeth II's reign and the events that shaped the second half of the 20th century.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2016,
        duration: "1h 58m",
        rating: "TV-MA",
        genre: ["Drama", "Historical"],
      },
      {
        id: "movie2",
        title: "Money Heist",
        description:
          "Eight thieves take hostages and lock themselves in the Royal Mint of Spain as a criminal mastermind manipulates the police to carry out his plan.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2017,
        duration: "1h 10m",
        rating: "TV-MA",
        genre: ["Crime", "Thriller"],
      },
      {
        id: "movie3",
        title: "Dark",
        description:
          "A missing child sets four families on a frantic hunt for answers as they unearth a mind-bending mystery that spans three generations.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2017,
        duration: "1h 30m",
        rating: "TV-MA",
        genre: ["Sci-Fi", "Thriller"],
      },
      {
        id: "movie4",
        title: "Squid Game",
        description:
          "Hundreds of cash-strapped players accept a strange invitation to compete in children's games. Inside, a tempting prize awaits — with deadly high stakes.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2021,
        duration: "1h 20m",
        rating: "TV-MA",
        genre: ["Drama", "Thriller"],
      },
      {
        id: "movie5",
        title: "The Witcher",
        description:
          "Geralt of Rivia, a mutated monster-hunter for hire, journeys toward his destiny in a turbulent world where people often prove more wicked than beasts.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2019,
        duration: "1h 40m",
        rating: "TV-MA",
        genre: ["Fantasy", "Action"],
      },
    ],
  },
  {
    id: "popular",
    title: "Popular on StreamFlix",
    items: [
      {
        id: "movie6",
        title: "Breaking Bad",
        description:
          "A high school chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine in order to secure his family's future.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2008,
        duration: "49m",
        rating: "TV-MA",
        genre: ["Crime", "Drama"],
      },
      {
        id: "movie7",
        title: "Peaky Blinders",
        description:
          "A notorious gang in 1919 Birmingham, England, is led by the fierce Tommy Shelby, a crime boss set on moving up in the world no matter the cost.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2013,
        duration: "1h",
        rating: "TV-MA",
        genre: ["Crime", "Drama"],
      },
      {
        id: "movie8",
        title: "Narcos",
        description:
          "The true story of Colombia's infamously violent and powerful drug cartels fuels this gritty gangster drama series.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2015,
        duration: "50m",
        rating: "TV-MA",
        genre: ["Crime", "Drama"],
      },
      {
        id: "movie9",
        title: "The Queen's Gambit",
        description:
          "In a 1950s orphanage, a young girl reveals an astonishing talent for chess and begins an unlikely journey to stardom while grappling with addiction.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2020,
        duration: "1h",
        rating: "TV-MA",
        genre: ["Drama"],
      },
      {
        id: "movie10",
        title: "Ozark",
        description:
          "A financial adviser drags his family from Chicago to the Missouri Ozarks, where he must launder $500 million in five years to appease a drug boss.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2017,
        duration: "1h",
        rating: "TV-MA",
        genre: ["Crime", "Drama"],
      },
    ],
  },
  {
    id: "originals",
    title: "StreamFlix Originals",
    items: [
      {
        id: "movie11",
        title: "The Umbrella Academy",
        description:
          "A dysfunctional family of adopted sibling superheroes reunites to solve the mystery of their father's death and the threat of an impending apocalypse.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2019,
        duration: "1h",
        rating: "TV-14",
        genre: ["Action", "Adventure"],
      },
      {
        id: "movie12",
        title: "Bridgerton",
        description:
          "The eight close-knit siblings of the Bridgerton family look for love and happiness in London high society.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2020,
        duration: "1h",
        rating: "TV-MA",
        genre: ["Drama", "Romance"],
      },
      {
        id: "movie13",
        title: "Lupin",
        description:
          "Inspired by the adventures of Arsène Lupin, gentleman thief Assane Diop sets out to avenge his father for an injustice inflicted by a wealthy family.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2021,
        duration: "45m",
        rating: "TV-MA",
        genre: ["Crime", "Mystery"],
      },
      {
        id: "movie14",
        title: "The Haunting of Hill House",
        description:
          "Flashing between past and present, a fractured family confronts haunting memories of their old home and the terrifying events that drove them from it.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2018,
        duration: "50m",
        rating: "TV-MA",
        genre: ["Horror", "Drama"],
      },
      {
        id: "movie15",
        title: "Mindhunter",
        description:
          "In the late 1970s, two FBI agents expand criminal science by delving into the psychology of murder and getting uneasily close to all-too-real monsters.",
        coverImage: "/placeholder.svg?height=400&width=600",
        thumbnailImage: "/placeholder.svg?height=200&width=300",
        releaseYear: 2017,
        duration: "1h",
        rating: "TV-MA",
        genre: ["Crime", "Drama"],
      },
    ],
  },
]

