"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-provider"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import Navbar from "@/components/navbar"
import { User, Lock, CreditCard, Bell } from "lucide-react"
import { Switch } from "@/components/ui/switch"

export default function ProfilePage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const { toast } = useToast()

  // Profile form state
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [isSaving, setIsSaving] = useState(false)

  // Password form state
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")

  // Notification settings
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [newReleases, setNewReleases] = useState(true)
  const [recommendations, setRecommendations] = useState(true)
  const [accountUpdates, setAccountUpdates] = useState(true)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    } else if (user) {
      setName(user.name)
      setEmail(user.email)
    }
  }, [mounted, loading, user, router])

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      // In a real app, this would be an API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: "There was an error updating your profile.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (newPassword !== confirmPassword) {
      toast({
        variant: "destructive",
        title: "Passwords do not match",
        description: "New password and confirm password must match.",
      })
      return
    }

    setIsSaving(true)

    try {
      // In a real app, this would be an API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      })

      setCurrentPassword("")
      setNewPassword("")
      setConfirmPassword("")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: "There was an error updating your password.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleNotificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      // In a real app, this would be an API call
      await new Promise((resolve) => setTimeout(resolve, 1000))

      toast({
        title: "Notification settings updated",
        description: "Your notification preferences have been updated successfully.",
      })
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: "There was an error updating your notification settings.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (loading || !mounted || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />

      <div className="pt-24 pb-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Account Settings</h1>

          <Tabs defaultValue="profile">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="md:w-64">
                <TabsList className="flex flex-col h-auto bg-transparent space-y-1">
                  <TabsTrigger
                    value="profile"
                    className="w-full justify-start px-4 py-3 data-[state=active]:bg-netflix-dark"
                  >
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </TabsTrigger>
                  <TabsTrigger
                    value="password"
                    className="w-full justify-start px-4 py-3 data-[state=active]:bg-netflix-dark"
                  >
                    <Lock className="mr-2 h-4 w-4" />
                    Password
                  </TabsTrigger>
                  <TabsTrigger
                    value="billing"
                    className="w-full justify-start px-4 py-3 data-[state=active]:bg-netflix-dark"
                  >
                    <CreditCard className="mr-2 h-4 w-4" />
                    Billing
                  </TabsTrigger>
                  <TabsTrigger
                    value="notifications"
                    className="w-full justify-start px-4 py-3 data-[state=active]:bg-netflix-dark"
                  >
                    <Bell className="mr-2 h-4 w-4" />
                    Notifications
                  </TabsTrigger>
                </TabsList>
              </div>

              <div className="flex-1">
                <TabsContent value="profile">
                  <Card className="bg-netflix-dark border-gray-800">
                    <CardHeader>
                      <CardTitle>Profile Information</CardTitle>
                      <CardDescription>Update your account profile information</CardDescription>
                    </CardHeader>
                    <form onSubmit={handleProfileSubmit}>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Name</Label>
                          <Input
                            id="name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="bg-gray-800"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="bg-gray-800"
                          />
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button type="submit" className="bg-netflix-red hover:bg-red-700" disabled={isSaving}>
                          {isSaving ? "Saving..." : "Save Changes"}
                        </Button>
                      </CardFooter>
                    </form>
                  </Card>
                </TabsContent>

                <TabsContent value="password">
                  <Card className="bg-netflix-dark border-gray-800">
                    <CardHeader>
                      <CardTitle>Change Password</CardTitle>
                      <CardDescription>Update your password</CardDescription>
                    </CardHeader>
                    <form onSubmit={handlePasswordSubmit}>
                      <CardContent className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="current-password">Current Password</Label>
                          <Input
                            id="current-password"
                            type="password"
                            value={currentPassword}
                            onChange={(e) => setCurrentPassword(e.target.value)}
                            className="bg-gray-800"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="new-password">New Password</Label>
                          <Input
                            id="new-password"
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            className="bg-gray-800"
                            required
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor="confirm-password">Confirm New Password</Label>
                          <Input
                            id="confirm-password"
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="bg-gray-800"
                            required
                          />
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button type="submit" className="bg-netflix-red hover:bg-red-700" disabled={isSaving}>
                          {isSaving ? "Updating..." : "Update Password"}
                        </Button>
                      </CardFooter>
                    </form>
                  </Card>
                </TabsContent>

                <TabsContent value="billing">
                  <Card className="bg-netflix-dark border-gray-800">
                    <CardHeader>
                      <CardTitle>Billing Information</CardTitle>
                      <CardDescription>Manage your subscription and payment methods</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-2">Current Plan</h3>
                        <div className="bg-gray-800 p-4 rounded-md">
                          <div className="flex justify-between items-center">
                            <div>
                              <p className="font-medium">
                                {user.subscription
                                  ? user.subscription.charAt(0).toUpperCase() + user.subscription.slice(1)
                                  : "No active subscription"}
                              </p>
                              {user.subscription && (
                                <p className="text-sm text-gray-400">
                                  {user.subscription === "premium"
                                    ? "$17.99"
                                    : user.subscription === "standard"
                                      ? "$13.99"
                                      : "$8.99"}{" "}
                                  / month
                                </p>
                              )}
                            </div>
                            <Button variant="outline" onClick={() => router.push("/subscription")}>
                              {user.subscription ? "Change Plan" : "Subscribe"}
                            </Button>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium mb-2">Payment Method</h3>
                        <div className="bg-gray-800 p-4 rounded-md">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center">
                              <CreditCard className="h-6 w-6 mr-2" />
                              <div>
                                <p className="font-medium">Visa ending in 1234</p>
                                <p className="text-sm text-gray-400">Expires 12/2025</p>
                              </div>
                            </div>
                            <Button variant="outline">Update</Button>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="text-lg font-medium mb-2">Billing History</h3>
                        <div className="bg-gray-800 rounded-md overflow-hidden">
                          <table className="w-full">
                            <thead>
                              <tr className="border-b border-gray-700">
                                <th className="text-left p-4">Date</th>
                                <th className="text-left p-4">Amount</th>
                                <th className="text-left p-4">Status</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr className="border-b border-gray-700">
                                <td className="p-4">Apr 1, 2023</td>
                                <td className="p-4">$17.99</td>
                                <td className="p-4">
                                  <span className="px-2 py-1 bg-green-500/20 text-green-500 rounded-full text-xs">
                                    Paid
                                  </span>
                                </td>
                              </tr>
                              <tr className="border-b border-gray-700">
                                <td className="p-4">Mar 1, 2023</td>
                                <td className="p-4">$17.99</td>
                                <td className="p-4">
                                  <span className="px-2 py-1 bg-green-500/20 text-green-500 rounded-full text-xs">
                                    Paid
                                  </span>
                                </td>
                              </tr>
                              <tr>
                                <td className="p-4">Feb 1, 2023</td>
                                <td className="p-4">$17.99</td>
                                <td className="p-4">
                                  <span className="px-2 py-1 bg-green-500/20 text-green-500 rounded-full text-xs">
                                    Paid
                                  </span>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="notifications">
                  <Card className="bg-netflix-dark border-gray-800">
                    <CardHeader>
                      <CardTitle>Notification Settings</CardTitle>
                      <CardDescription>Manage your notification preferences</CardDescription>
                    </CardHeader>
                    <form onSubmit={handleNotificationSubmit}>
                      <CardContent className="space-y-6">
                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="email-notifications">Email Notifications</Label>
                            <p className="text-sm text-gray-400">
                              Receive emails about your account, new features and more
                            </p>
                          </div>
                          <Switch
                            id="email-notifications"
                            checked={emailNotifications}
                            onCheckedChange={setEmailNotifications}
                          />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="new-releases">New Releases</Label>
                            <p className="text-sm text-gray-400">Get notified when new movies or shows are added</p>
                          </div>
                          <Switch id="new-releases" checked={newReleases} onCheckedChange={setNewReleases} />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="recommendations">Recommendations</Label>
                            <p className="text-sm text-gray-400">
                              Receive personalized recommendations based on your viewing history
                            </p>
                          </div>
                          <Switch id="recommendations" checked={recommendations} onCheckedChange={setRecommendations} />
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="space-y-0.5">
                            <Label htmlFor="account-updates">Account Updates</Label>
                            <p className="text-sm text-gray-400">
                              Get important updates about your account and billing
                            </p>
                          </div>
                          <Switch id="account-updates" checked={accountUpdates} onCheckedChange={setAccountUpdates} />
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button type="submit" className="bg-netflix-red hover:bg-red-700" disabled={isSaving}>
                          {isSaving ? "Saving..." : "Save Preferences"}
                        </Button>
                      </CardFooter>
                    </form>
                  </Card>
                </TabsContent>
              </div>
            </div>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

