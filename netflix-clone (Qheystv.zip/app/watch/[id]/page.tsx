"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Volume2, VolumeX, Maximize, Pause, Play } from "lucide-react"
import { useAuth } from "@/lib/auth-provider"
import { mockContent } from "@/lib/mock-data"

export default function WatchPage({ params }: { params: { id: string } }) {
  const { id } = params
  const { user, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(false)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    }
  }, [mounted, loading, user, router])

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            return 100
          }
          return prev + 0.1
        })
      }, 100)

      return () => clearInterval(interval)
    }
  }, [isPlaying])

  const handleBack = () => {
    router.back()
  }

  const togglePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  // Find content from mock data
  const allContent = mockContent.flatMap((category) => (category.items ? category.items : [category]))
  const content = allContent.find((item) => item.id === id)

  if (loading || !mounted || !user || !content) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="relative h-screen w-full bg-black">
      <div className="absolute inset-0 z-10">
        <img
          src={content.coverImage || "/placeholder.svg"}
          alt={content.title}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="absolute inset-0 z-20 flex flex-col justify-between p-4">
        <div className="flex items-center">
          <button onClick={handleBack} className="bg-black bg-opacity-50 p-2 rounded-full">
            <ArrowLeft className="h-6 w-6" />
          </button>
        </div>

        <div className="flex flex-col">
          <div className="flex items-center justify-center mb-4">
            <button onClick={togglePlay} className="bg-white bg-opacity-10 p-4 rounded-full mx-2">
              {isPlaying ? <Pause className="h-8 w-8" /> : <Play className="h-8 w-8" />}
            </button>

            <button onClick={toggleMute} className="bg-white bg-opacity-10 p-4 rounded-full mx-2">
              {isMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
            </button>

            <button className="bg-white bg-opacity-10 p-4 rounded-full mx-2">
              <Maximize className="h-6 w-6" />
            </button>
          </div>

          <div className="w-full bg-gray-600 h-1 rounded-full overflow-hidden">
            <div className="bg-netflix-red h-full" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      </div>
    </div>
  )
}

