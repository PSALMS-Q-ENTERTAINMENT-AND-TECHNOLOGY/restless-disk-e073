"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/lib/auth-provider"
import Navbar from "@/components/navbar"
import { useToast } from "@/components/ui/use-toast"

const plans = [
  {
    id: "basic",
    name: "Basic",
    price: 8.99,
    features: [
      "Good video quality",
      "Resolution: 720p",
      "Watch on your TV, computer, mobile phone and tablet",
      "Download titles to watch offline",
    ],
    videoQuality: "Good",
    resolution: "720p",
    devices: ["TV", "Computer", "Mobile phone", "Tablet"],
  },
  {
    id: "standard",
    name: "Standard",
    price: 13.99,
    features: [
      "Better video quality",
      "Resolution: 1080p",
      "Watch on your TV, computer, mobile phone and tablet",
      "Download titles to watch offline",
      "Watch on 2 screens at the same time",
    ],
    videoQuality: "Better",
    resolution: "1080p",
    devices: ["TV", "Computer", "Mobile phone", "Tablet"],
    screens: 2,
  },
  {
    id: "premium",
    name: "Premium",
    price: 17.99,
    features: [
      "Best video quality",
      "Resolution: 4K+HDR",
      "Watch on your TV, computer, mobile phone and tablet",
      "Download titles to watch offline",
      "Watch on 4 screens at the same time",
      "Spatial audio",
    ],
    videoQuality: "Best",
    resolution: "4K+HDR",
    devices: ["TV", "Computer", "Mobile phone", "Tablet"],
    screens: 4,
  },
]

export default function SubscriptionPage() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    } else if (user?.subscription) {
      setSelectedPlan(user.subscription)
    }
  }, [mounted, loading, user, router])

  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId)
  }

  const handleSubscribe = async () => {
    if (!selectedPlan) return

    setIsProcessing(true)

    try {
      // In a real app, this would be an API call to your payment processor
      await new Promise((resolve) => setTimeout(resolve, 2000))

      toast({
        title: "Subscription successful",
        description: `You are now subscribed to the ${selectedPlan} plan.`,
      })

      // Redirect to browse page
      router.push("/browse")
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Subscription failed",
        description: "There was an error processing your subscription.",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  if (loading || !mounted || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />

      <div className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">Choose the plan that's right for you</h1>
            <p className="text-lg text-gray-300">Downgrade or upgrade at any time</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card
                key={plan.id}
                className={`bg-netflix-dark border-2 ${selectedPlan === plan.id ? "border-netflix-red" : "border-gray-700"}`}
              >
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>${plan.price}/month</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="h-5 w-5 text-green-500 mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button
                    className={`w-full ${selectedPlan === plan.id ? "bg-netflix-red hover:bg-red-700" : "bg-gray-700 hover:bg-gray-600"}`}
                    onClick={() => handleSelectPlan(plan.id)}
                  >
                    {selectedPlan === plan.id ? "Selected" : "Select Plan"}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Button
              className="bg-netflix-red hover:bg-red-700 text-white px-8 py-6 text-lg"
              disabled={!selectedPlan || isProcessing}
              onClick={handleSubscribe}
            >
              {isProcessing ? "Processing..." : "Subscribe Now"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}

