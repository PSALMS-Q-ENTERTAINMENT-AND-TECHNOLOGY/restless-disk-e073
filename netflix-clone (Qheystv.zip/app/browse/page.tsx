"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-provider"
import Navbar from "@/components/navbar"
import HeroSection from "@/components/hero-section"
import ContentRow from "@/components/content-row"
import { mockContent } from "@/lib/mock-data"

export default function Browse() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    }
  }, [mounted, loading, user, router])

  if (loading || !mounted || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  const featuredContent = mockContent.find((item) => item.id === "featured")
  const categories = mockContent.filter((item) => item.id !== "featured")

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />

      {featuredContent && (
        <HeroSection
          title={featuredContent.title}
          description={featuredContent.description || ""}
          imageUrl={featuredContent.coverImage}
          videoId={featuredContent.id}
        />
      )}

      <div className="pb-20 -mt-40 relative z-10">
        {categories.map((category) => (
          <ContentRow key={category.id} title={category.title} items={category.items || []} />
        ))}
      </div>
    </div>
  )
}

