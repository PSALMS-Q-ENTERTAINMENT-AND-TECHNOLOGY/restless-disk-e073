import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ChevronRight } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="w-full px-4 py-3 flex justify-between items-center bg-gradient-to-b from-black to-transparent absolute z-10">
        <div className="flex items-center">
          <Link href="/">
            <h1 className="text-netflix-red text-4xl font-bold">STREAMFLIX</h1>
          </Link>
        </div>
        <div>
          <Link href="/login">
            <Button variant="default" className="bg-netflix-red hover:bg-red-700 text-white">
              Sign In
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-grow">
        <div
          className="h-screen w-full bg-cover bg-center relative"
          style={{
            backgroundImage: `url('/placeholder.svg?height=1080&width=1920')`,
            backgroundSize: "cover",
          }}
        >
          <div className="absolute inset-0 hero-gradient"></div>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">Unlimited movies, TV shows, and more</h1>
            <p className="text-xl md:text-2xl mb-6">Watch anywhere. Cancel anytime.</p>
            <p className="text-lg md:text-xl mb-8">
              Ready to watch? Enter your email to create or restart your membership.
            </p>
            <div className="flex flex-col sm:flex-row gap-2 w-full max-w-md">
              <Link href="/signup" className="w-full">
                <Button className="w-full bg-netflix-red hover:bg-red-700 text-white text-lg py-6">
                  Get Started <ChevronRight className="ml-2" />
                </Button>
              </Link>
            </div>
          </div>
        </div>

        <section className="py-16 border-t-8 border-gray-800 bg-black">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-8 md:mb-0">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Enjoy on your TV</h2>
                <p className="text-lg md:text-xl">
                  Watch on Smart TVs, Playstation, Xbox, Chromecast, Apple TV, Blu-ray players, and more.
                </p>
              </div>
              <div className="md:w-1/2 relative">
                <img src="/placeholder.svg?height=400&width=600" alt="TV" className="w-full rounded-lg" />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 border-t-8 border-gray-800 bg-black">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row-reverse items-center">
              <div className="md:w-1/2 mb-8 md:mb-0">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Download your shows to watch offline</h2>
                <p className="text-lg md:text-xl">Save your favorites easily and always have something to watch.</p>
              </div>
              <div className="md:w-1/2 relative">
                <img src="/placeholder.svg?height=400&width=600" alt="Mobile device" className="w-full rounded-lg" />
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 border-t-8 border-gray-800 bg-black">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center">
              <div className="md:w-1/2 mb-8 md:mb-0">
                <h2 className="text-3xl md:text-4xl font-bold mb-4">Watch everywhere</h2>
                <p className="text-lg md:text-xl">
                  Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV.
                </p>
              </div>
              <div className="md:w-1/2 relative">
                <img src="/placeholder.svg?height=400&width=600" alt="Devices" className="w-full rounded-lg" />
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-black text-gray-500 py-8 border-t border-gray-800">
        <div className="container mx-auto px-4">
          <p className="mb-4">Questions? Call 1-800-123-4567</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Investor Relations
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Privacy
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Speed Test
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Help Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Jobs
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Cookie Preferences
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Legal Notices
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Account
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Ways to Watch
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Corporate Information
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Only on StreamFlix
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Media Center
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Terms of Use
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <p className="mt-8">StreamFlix</p>
        </div>
      </footer>
    </div>
  )
}

