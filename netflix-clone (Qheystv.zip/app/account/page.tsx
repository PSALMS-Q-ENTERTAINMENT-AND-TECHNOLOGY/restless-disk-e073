"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-provider"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import Navbar from "@/components/navbar"
import { AlertTriangle, CheckCircle, CreditCard, User, Users } from "lucide-react"

export default function AccountPage() {
  const { user, loading, logout } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const { toast } = useToast()
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    }
  }, [mounted, loading, user, router])

  const handleDeleteAccount = async () => {
    if (window.confirm("Are you sure you want to delete your account? This action cannot be undone.")) {
      setIsDeleting(true)

      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1500))

        toast({
          title: "Account deleted",
          description: "Your account has been successfully deleted.",
        })

        logout()
        router.push("/")
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "There was an error deleting your account.",
        })
        setIsDeleting(false)
      }
    }
  }

  if (loading || !mounted || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />

      <div className="pt-24 pb-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8">Account Overview</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="bg-netflix-dark border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2 text-netflix-red" />
                  Account Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Name:</span>
                    <span>{user.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Email:</span>
                    <span>{user.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Member Since:</span>
                    <span>January 2023</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => router.push("/profile")}>
                  Edit Profile
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-netflix-dark border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center">
                  <CreditCard className="h-5 w-5 mr-2 text-netflix-red" />
                  Subscription Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Current Plan:</span>
                    <span>
                      {user.subscription
                        ? user.subscription.charAt(0).toUpperCase() + user.subscription.slice(1)
                        : "No active subscription"}
                    </span>
                  </div>
                  {user.subscription && (
                    <>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Price:</span>
                        <span>
                          {user.subscription === "premium"
                            ? "$17.99"
                            : user.subscription === "standard"
                              ? "$13.99"
                              : "$8.99"}{" "}
                          / month
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Next Billing:</span>
                        <span>May 1, 2023</span>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => router.push("/subscription")}>
                  {user.subscription ? "Change Plan" : "Subscribe Now"}
                </Button>
              </CardFooter>
            </Card>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <Card className="bg-netflix-dark border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-netflix-red" />
                  Profiles
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded bg-blue-600 flex items-center justify-center mr-3">
                        <span className="font-bold">J</span>
                      </div>
                      <span>John</span>
                    </div>
                    <span className="text-xs bg-gray-700 px-2 py-1 rounded">Primary</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded bg-green-600 flex items-center justify-center mr-3">
                        <span className="font-bold">S</span>
                      </div>
                      <span>Sarah</span>
                    </div>
                    <Button variant="ghost" size="sm" className="h-7 text-xs">
                      Edit
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded bg-purple-600 flex items-center justify-center mr-3">
                        <span className="font-bold">K</span>
                      </div>
                      <span>Kids</span>
                    </div>
                    <Button variant="ghost" size="sm" className="h-7 text-xs">
                      Edit
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Manage Profiles
                </Button>
              </CardFooter>
            </Card>

            <Card className="bg-netflix-dark border-gray-800">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-netflix-red" />
                  Account Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-gray-800 rounded-md">
                    <h3 className="font-medium mb-1">Sign out of all devices</h3>
                    <p className="text-sm text-gray-400 mb-3">
                      Sign out from all devices where you're currently logged in
                    </p>
                    <Button variant="outline" size="sm">
                      Sign Out Everywhere
                    </Button>
                  </div>

                  <div className="p-3 bg-gray-800 rounded-md">
                    <h3 className="font-medium mb-1">Download your data</h3>
                    <p className="text-sm text-gray-400 mb-3">Request a copy of all your account data</p>
                    <Button variant="outline" size="sm">
                      Request Data
                    </Button>
                  </div>

                  <div className="p-3 bg-red-900/20 border border-red-900/50 rounded-md">
                    <h3 className="font-medium text-red-400 mb-1">Delete account</h3>
                    <p className="text-sm text-gray-400 mb-3">Permanently delete your account and all data</p>
                    <Button variant="destructive" size="sm" onClick={handleDeleteAccount} disabled={isDeleting}>
                      {isDeleting ? "Deleting..." : "Delete Account"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-netflix-dark border-gray-800">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-netflix-red" />
                Recent Activity
              </CardTitle>
              <CardDescription>Your recent account activity</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-gray-800 pb-3">
                  <div>
                    <p className="font-medium">Account Login</p>
                    <p className="text-sm text-gray-400">New York, United States</p>
                  </div>
                  <p className="text-sm text-gray-400">Today, 10:30 AM</p>
                </div>

                <div className="flex justify-between items-center border-b border-gray-800 pb-3">
                  <div>
                    <p className="font-medium">Password Changed</p>
                    <p className="text-sm text-gray-400">Chicago, United States</p>
                  </div>
                  <p className="text-sm text-gray-400">Apr 15, 2023</p>
                </div>

                <div className="flex justify-between items-center border-b border-gray-800 pb-3">
                  <div>
                    <p className="font-medium">Subscription Renewed</p>
                    <p className="text-sm text-gray-400">Premium Plan - $17.99</p>
                  </div>
                  <p className="text-sm text-gray-400">Apr 1, 2023</p>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">New Device Added</p>
                    <p className="text-sm text-gray-400">iPhone 13 Pro - iOS 16.2</p>
                  </div>
                  <p className="text-sm text-gray-400">Mar 28, 2023</p>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View All Activity
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

