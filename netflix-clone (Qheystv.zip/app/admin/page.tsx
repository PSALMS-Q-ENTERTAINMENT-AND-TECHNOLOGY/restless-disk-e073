"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-provider"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { mockContent } from "@/lib/mock-data"
import { Edit, Trash, Plus, Upload, BarChart, Users, DollarSign, Film } from "lucide-react"

export default function AdminDashboard() {
  const { user, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)
  const [activeTab, setActiveTab] = useState("content")

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    }
  }, [mounted, loading, user, router])

  if (loading || !mounted || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  // Flatten all content items
  const allContent = mockContent.flatMap((category) => (category.items ? category.items : [category]))

  return (
    <div className="min-h-screen bg-netflix-black">
      <header className="bg-netflix-dark border-b border-gray-800 py-4 px-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-netflix-red text-2xl font-bold">STREAMFLIX ADMIN</h1>
          </div>
          <Button variant="outline" className="border-gray-600" onClick={() => router.push("/browse")}>
            Back to App
          </Button>
        </div>
      </header>

      <div className="container mx-auto py-8 px-4">
        <Tabs defaultValue="content" onValueChange={setActiveTab}>
          <TabsList className="mb-8 bg-netflix-dark">
            <TabsTrigger value="content">Content Management</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="payments">Payments</TabsTrigger>
          </TabsList>

          <TabsContent value="content">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Content Library</h2>
              <Button className="bg-netflix-red hover:bg-red-700">
                <Plus className="mr-2 h-4 w-4" /> Add New Content
              </Button>
            </div>

            <Card className="bg-netflix-dark border-gray-800">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark">
                      <TableHead className="w-[100px]">ID</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Release Year</TableHead>
                      <TableHead>Rating</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {allContent.map((item) => (
                      <TableRow key={item.id} className="border-gray-800 hover:bg-netflix-dark/50">
                        <TableCell className="font-medium">{item.id}</TableCell>
                        <TableCell>{item.title}</TableCell>
                        <TableCell>{item.genre ? item.genre[0] : "N/A"}</TableCell>
                        <TableCell>{item.releaseYear || "N/A"}</TableCell>
                        <TableCell>{item.rating || "N/A"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button variant="outline" size="icon" className="h-8 w-8">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="icon" className="h-8 w-8 text-red-500 hover:text-red-600">
                              <Trash className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">User Management</h2>
              <Button className="bg-netflix-red hover:bg-red-700">
                <Plus className="mr-2 h-4 w-4" /> Add New User
              </Button>
            </div>

            <Card className="bg-netflix-dark border-gray-800">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark">
                      <TableHead className="w-[100px]">ID</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Subscription</TableHead>
                      <TableHead>Join Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                      <TableCell className="font-medium">1</TableCell>
                      <TableCell>John Doe</TableCell>
                      <TableCell>john@example.com</TableCell>
                      <TableCell>Premium</TableCell>
                      <TableCell>Jan 10, 2023</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="icon" className="h-8 w-8 text-red-500 hover:text-red-600">
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                      <TableCell className="font-medium">2</TableCell>
                      <TableCell>Jane Smith</TableCell>
                      <TableCell>jane@example.com</TableCell>
                      <TableCell>Standard</TableCell>
                      <TableCell>Mar 15, 2023</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button variant="outline" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="icon" className="h-8 w-8 text-red-500 hover:text-red-600">
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="bg-netflix-dark border-gray-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Total Users</CardTitle>
                  <CardDescription>Active subscriptions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <Users className="h-8 w-8 text-netflix-red mr-4" />
                    <div>
                      <p className="text-4xl font-bold">12,345</p>
                      <p className="text-green-500 text-sm mt-2">+12% from last month</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-netflix-dark border-gray-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Revenue</CardTitle>
                  <CardDescription>Monthly recurring</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <DollarSign className="h-8 w-8 text-netflix-red mr-4" />
                    <div>
                      <p className="text-4xl font-bold">$198,532</p>
                      <p className="text-green-500 text-sm mt-2">+8% from last month</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-netflix-dark border-gray-800">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Content</CardTitle>
                  <CardDescription>Total titles</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center">
                    <Film className="h-8 w-8 text-netflix-red mr-4" />
                    <div>
                      <p className="text-4xl font-bold">2,845</p>
                      <p className="text-green-500 text-sm mt-2">+24 new this month</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-netflix-dark border-gray-800">
                <CardHeader>
                  <CardTitle>Subscription Growth</CardTitle>
                  <CardDescription>New subscribers over time</CardDescription>
                </CardHeader>
                <CardContent className="h-80 flex items-center justify-center">
                  <div className="text-center">
                    <BarChart className="h-16 w-16 text-netflix-red mx-auto mb-4" />
                    <p className="text-gray-400">Subscription growth chart would appear here</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-netflix-dark border-gray-800">
                <CardHeader>
                  <CardTitle>Popular Content</CardTitle>
                  <CardDescription>Most watched titles</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow className="border-gray-800 hover:bg-netflix-dark">
                        <TableHead>Title</TableHead>
                        <TableHead>Views</TableHead>
                        <TableHead>Completion Rate</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                        <TableCell>Stranger Things</TableCell>
                        <TableCell>1,245,678</TableCell>
                        <TableCell>92%</TableCell>
                      </TableRow>
                      <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                        <TableCell>The Crown</TableCell>
                        <TableCell>987,543</TableCell>
                        <TableCell>88%</TableCell>
                      </TableRow>
                      <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                        <TableCell>Money Heist</TableCell>
                        <TableCell>876,432</TableCell>
                        <TableCell>85%</TableCell>
                      </TableRow>
                      <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                        <TableCell>Squid Game</TableCell>
                        <TableCell>765,321</TableCell>
                        <TableCell>94%</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="payments">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Payment History</h2>
              <Button className="bg-netflix-red hover:bg-red-700">
                <Upload className="mr-2 h-4 w-4" /> Export Data
              </Button>
            </div>

            <Card className="bg-netflix-dark border-gray-800">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark">
                      <TableHead className="w-[100px]">Transaction ID</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                      <TableCell className="font-medium">TX-12345</TableCell>
                      <TableCell>John Doe</TableCell>
                      <TableCell>Premium</TableCell>
                      <TableCell>$17.99</TableCell>
                      <TableCell>Apr 1, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 bg-green-500/20 text-green-500 rounded-full text-xs">Completed</span>
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                      <TableCell className="font-medium">TX-12346</TableCell>
                      <TableCell>Jane Smith</TableCell>
                      <TableCell>Standard</TableCell>
                      <TableCell>$13.99</TableCell>
                      <TableCell>Apr 2, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 bg-green-500/20 text-green-500 rounded-full text-xs">Completed</span>
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                      <TableCell className="font-medium">TX-12347</TableCell>
                      <TableCell>Mike Johnson</TableCell>
                      <TableCell>Basic</TableCell>
                      <TableCell>$8.99</TableCell>
                      <TableCell>Apr 3, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 bg-yellow-500/20 text-yellow-500 rounded-full text-xs">Pending</span>
                      </TableCell>
                    </TableRow>
                    <TableRow className="border-gray-800 hover:bg-netflix-dark/50">
                      <TableCell className="font-medium">TX-12348</TableCell>
                      <TableCell>Sarah Williams</TableCell>
                      <TableCell>Premium</TableCell>
                      <TableCell>$17.99</TableCell>
                      <TableCell>Apr 4, 2023</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 bg-red-500/20 text-red-500 rounded-full text-xs">Failed</span>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

