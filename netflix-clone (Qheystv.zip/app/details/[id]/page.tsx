"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Play, Plus, ThumbsUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth-provider"
import { mockContent } from "@/lib/mock-data"
import Navbar from "@/components/navbar"
import ContentRow from "@/components/content-row"

export default function DetailsPage({ params }: { params: { id: string } }) {
  const { id } = params
  const { user, loading } = useAuth()
  const router = useRouter()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !loading && !user) {
      router.push("/login")
    }
  }, [mounted, loading, user, router])

  // Find content from mock data
  const allContent = mockContent.flatMap((category) => (category.items ? category.items : [category]))
  const content = allContent.find((item) => item.id === id)

  // Find similar content
  const similarContent = allContent
    .filter(
      (item) => item.id !== id && item.genre && content?.genre && item.genre.some((g) => content.genre?.includes(g)),
    )
    .slice(0, 10)

  if (loading || !mounted || !user || !content) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-12 h-12 border-4 border-netflix-red border-t-transparent rounded-full animate-spin"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-netflix-black">
      <Navbar />

      <div className="relative pt-16">
        <div
          className="w-full h-[70vh] bg-cover bg-center relative"
          style={{ backgroundImage: `url(${content.coverImage})` }}
        >
          <div className="absolute inset-0 hero-gradient"></div>

          <div className="absolute bottom-0 left-0 p-8 md:p-16 w-full md:w-1/2 z-10">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">{content.title}</h1>

            <div className="flex items-center space-x-4 mb-4">
              <span className="text-green-500 font-semibold">{content.rating}</span>
              <span>{content.releaseYear}</span>
              <span>{content.duration}</span>
            </div>

            <p className="text-lg mb-6">{content.description}</p>

            <div className="flex space-x-4">
              <Button
                className="bg-white text-black hover:bg-gray-200 flex items-center gap-2"
                onClick={() => router.push(`/watch/${content.id}`)}
              >
                <Play className="h-5 w-5" />
                Play
              </Button>

              <Button variant="outline" className="flex items-center gap-2">
                <Plus className="h-5 w-5" />
                My List
              </Button>

              <Button variant="outline" className="flex items-center gap-2">
                <ThumbsUp className="h-5 w-5" />
                Like
              </Button>
            </div>
          </div>
        </div>

        <div className="px-4 md:px-16 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="col-span-2">
              <h2 className="text-2xl font-semibold mb-4">About {content.title}</h2>
              <p className="text-gray-300">{content.description}</p>
            </div>

            <div>
              <div className="mb-4">
                <span className="text-gray-400">Genres: </span>
                <span>{content.genre?.join(", ")}</span>
              </div>

              <div className="mb-4">
                <span className="text-gray-400">Release year: </span>
                <span>{content.releaseYear}</span>
              </div>

              <div>
                <span className="text-gray-400">Rating: </span>
                <span>{content.rating}</span>
              </div>
            </div>
          </div>
        </div>

        {similarContent.length > 0 && (
          <div className="mt-8">
            <ContentRow title="More Like This" items={similarContent} />
          </div>
        )}
      </div>
    </div>
  )
}

