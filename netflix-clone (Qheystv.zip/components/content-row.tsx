"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"
import type { ContentItem } from "@/lib/mock-data"

interface ContentRowProps {
  title: string
  items: ContentItem[]
}

export default function ContentRow({ title, items }: ContentRowProps) {
  const [startIndex, setStartIndex] = useState(0)
  const itemsPerPage = 5
  const canScrollLeft = startIndex > 0
  const canScrollRight = startIndex + itemsPerPage < items.length

  const handleScrollLeft = () => {
    if (canScrollLeft) {
      setStartIndex(Math.max(0, startIndex - itemsPerPage))
    }
  }

  const handleScrollRight = () => {
    if (canScrollRight) {
      setStartIndex(Math.min(items.length - itemsPerPage, startIndex + itemsPerPage))
    }
  }

  return (
    <div className="px-4 md:px-16 mt-6 space-y-2">
      <h2 className="text-xl font-semibold">{title}</h2>

      <div className="relative group">
        <div className="flex items-center">
          {canScrollLeft && (
            <button
              onClick={handleScrollLeft}
              className="absolute left-0 z-40 bg-black bg-opacity-50 p-2 rounded-full transform -translate-y-1/2 top-1/2 opacity-0 group-hover:opacity-100 transition"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
          )}

          <div className="flex space-x-2 overflow-x-hidden">
            {items.slice(startIndex, startIndex + itemsPerPage).map((item) => (
              <Link
                key={item.id}
                href={`/details/${item.id}`}
                className="flex-shrink-0 w-[calc(20%-8px)] video-card-hover"
              >
                <div className="relative aspect-video rounded-md overflow-hidden">
                  <img
                    src={item.thumbnailImage || item.coverImage}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-20 transition-opacity"></div>
                </div>
              </Link>
            ))}
          </div>

          {canScrollRight && (
            <button
              onClick={handleScrollRight}
              className="absolute right-0 z-40 bg-black bg-opacity-50 p-2 rounded-full transform -translate-y-1/2 top-1/2 opacity-0 group-hover:opacity-100 transition"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

