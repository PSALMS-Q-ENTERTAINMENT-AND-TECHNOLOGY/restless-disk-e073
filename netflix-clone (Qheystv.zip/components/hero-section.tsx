import Link from "next/link"
import { Play, Info } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HeroSectionProps {
  title: string
  description: string
  imageUrl: string
  videoId: string
}

export default function HeroSection({ title, description, imageUrl, videoId }: HeroSectionProps) {
  return (
    <div className="relative h-[80vh] w-full">
      <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url(${imageUrl})` }}>
        <div className="absolute inset-0 hero-gradient"></div>
      </div>

      <div className="absolute bottom-0 left-0 p-8 md:p-16 w-full md:w-1/2 z-10">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">{title}</h1>
        <p className="text-lg mb-6 line-clamp-3">{description}</p>

        <div className="flex space-x-4">
          <Link href={`/watch/${videoId}`}>
            <Button className="bg-white text-black hover:bg-gray-200 flex items-center gap-2">
              <Play className="h-5 w-5" />
              Play
            </Button>
          </Link>

          <Link href={`/details/${videoId}`}>
            <Button
              variant="secondary"
              className="bg-gray-500 bg-opacity-70 hover:bg-opacity-90 flex items-center gap-2"
            >
              <Info className="h-5 w-5" />
              More Info
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

