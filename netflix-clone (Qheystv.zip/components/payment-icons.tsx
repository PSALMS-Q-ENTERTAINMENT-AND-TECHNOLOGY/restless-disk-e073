import type React from "react"
export function CreditCard(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="14" x="2" y="5" rx="2" />
      <line x1="2" x2="22" y1="10" y2="10" />
    </svg>
  )
}

export function PaypalIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
      <path
        d="M7.144 19.532H4.6a.554.554 0 0 1-.547-.462L2.025 6.2A.554.554 0 0 1 2.572 5.6h5.4c2.9 0 4.973 2.1 4.8 4.6-.173 2.5-2.3 4.6-5.2 4.6H5.844l-.577 4.2a.554.554 0 0 1-.547.532h-1.3"
        stroke="#009cde"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M9.745 10.2c-.173 2.5-2.3 4.6-5.2 4.6H2.917l-.865 6.3a.554.554 0 0 1-.547.532h-1.3"
        stroke="#003087"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.144 19.532h-2.544a.554.554 0 0 1-.547-.462L13.025 6.2a.554.554 0 0 1 .547-.6h5.4c2.9 0 4.973 2.1 4.8 4.6-.173 2.5-2.3 4.6-5.2 4.6h-1.728l-.577 4.2a.554.554 0 0 1-.547.532h-1.3"
        stroke="#003087"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M20.745 10.2c-.173 2.5-2.3 4.6-5.2 4.6h-1.628l-.865 6.3a.554.554 0 0 1-.547.532h-1.3"
        stroke="#009cde"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

