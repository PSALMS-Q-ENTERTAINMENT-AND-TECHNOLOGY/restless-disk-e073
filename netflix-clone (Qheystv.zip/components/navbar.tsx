"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Bell, Search, ChevronDown, User } from "lucide-react"
import { useAuth } from "@/lib/auth-provider"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const { user, logout } = useAuth()
  const router = useRouter()

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setIsScrolled(true)
      } else {
        setIsScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 z-50 w-full transition-colors duration-300 ${isScrolled ? "bg-netflix-black" : "bg-transparent"}`}
    >
      <div className="px-4 md:px-16 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <Link href="/browse">
            <h1 className="text-netflix-red text-3xl font-bold">STREAMFLIX</h1>
          </Link>

          <nav className="hidden md:flex space-x-4">
            <Link href="/browse" className="text-sm text-white hover:text-gray-300">
              Home
            </Link>
            <Link href="/browse/tv-shows" className="text-sm text-gray-300 hover:text-white">
              TV Shows
            </Link>
            <Link href="/browse/movies" className="text-sm text-gray-300 hover:text-white">
              Movies
            </Link>
            <Link href="/browse/new" className="text-sm text-gray-300 hover:text-white">
              New & Popular
            </Link>
            <Link href="/browse/my-list" className="text-sm text-gray-300 hover:text-white">
              My List
            </Link>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          <button className="text-gray-200 hover:text-white">
            <Search className="h-5 w-5" />
          </button>

          <button className="text-gray-200 hover:text-white">
            <Bell className="h-5 w-5" />
          </button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center space-x-2 text-gray-200 hover:text-white">
                <div className="w-8 h-8 rounded-md bg-gray-600 flex items-center justify-center">
                  <User className="h-5 w-5" />
                </div>
                <ChevronDown className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56 bg-netflix-dark border-gray-700">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => router.push("/profile")}>Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/account")}>Account</DropdownMenuItem>
              <DropdownMenuItem onClick={() => router.push("/subscription")}>Subscription</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout}>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}

